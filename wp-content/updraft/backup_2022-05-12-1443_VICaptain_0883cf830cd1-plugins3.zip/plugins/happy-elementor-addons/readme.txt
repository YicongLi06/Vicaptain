=== Happy Addons for Elementor (Mega Menu, Post Grid, Woocommerce Product Grid, Table, Event Calendar, Slider Elementor Widget) ===
Plugin Name: Happy Addons for Elementor (Mega Menu, Post Grid, Woocommerce Product Grid, Table, Event Calendar, Slider Elementor Widget)
Version: 3.5.1
Author: weDevs
Author URI: https://happyaddons.com/
Contributors: happyaddons, thehappymonster, wedevs
Tags: Elementor, Elementor Addons, Elementor Widget, Elementor Addon, Mega Menu
Requires at least: 4.7
Tested up to: 5.9
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

[Happy Addons for Elementor](https://happyaddons.com/) Is the Best Elementor Addons Comes With 48+ Free Elementor Widgets Including Table Builder, Testimonial, Event Calendar,Slider,News Ticker, Image Grid, etc & Features Like Elementor Equal Height, Text Stroke, Shape Dividers, Floating Effect, Grid Layout, 500+ Elementor Icons, 450+ Template Packs & More.

== Description ==

[Happy Addons for Elementor page builder](https://happyaddons.com/) Is One of the Best Elementor Addons That Comes With **97+ Elementor Free & Pro Widgets and 20+ Problem-Solving Elementor Features**. And HappyAddons Elementor widgets are not limited to customizations. All the Elementor widget is stand out from other third-party elementor addons widgets in terms of flexibility of customizations. Also, we are not locking the features of Elementor widgets in the free versions. All the free Elementor widgets are like our premium elementor widgets. HappyAddons for Elementor (**Mega Menu Builder, Elementor Template, Post Grid, Woocommerce Product Grid, Table, Tooltips, Slider Elementor Widget**) will broaden your elementor related designing skills. Our **70+ full-page Elementor Templates and 400+ readymade elementor blocks** will help you to kickstart your works swiftly. So try Happy Elementor Addon to create amazing Elementor Websites. 


**WHY SHOULD YOU CHOOSE HAPPYADDONS FOR ELEMENTOR?**

HappyAddons is the pioneer of adding exclusive problem-solving Elementor features. Also, we have added premium quality Elementor Widgets in the Elementor Widget Library. Reasons for choosing Happyaddons over any other Elementor Addons:



1. From now on, you can create an Elementor mega menu, simple navigation menu, Horizontal Nav Menu with our Happy Elementor Menu Widget.
2. Create off canvas contents or of canvas elementor menu for your site with Happy Elementor Addons off-canvas elementor widget
3. Manage one page navigation elementor menu with the help of HappyAddons One Page Navigation Elementor widget
4. You Can Create an Advanced Data Table within elementor.
5. Ability to add google sheet to your elementor website.
6. Facility to Add Text Stroke or Outline to Elementor Typography
7. Manage Your Event Calendars,
8. Add google calendar within Elementor using the Event calendar elementor widget.
9. Design Your Woocommerce Sites with HappyAddons WooCommerce Elementor widget pack. 
10. WooCommerce product grid page with HappyAddons elementor product grid widget.
11. Create Product carousel with HappyAddons Product carousel Elementor widget.
12. Create blog grid or post gird or blog archive page with Happy Elementor Post Grid widget
13. Add post carousel to your Elementor site with HappyAddons Elementor Post Carousel widget
14. Copy and Paste All of Your Elements Within Cross-Domain elementor sites,
15. Masking Your Images Into Different Shapes Within the Elementor Editing Panel,
16. Flexibility to Create Advance Background Parallax for Your Elementor Site,
17. Create Elementor tooltips within any element of the Elementor site. 
18. Create a stunning pricing menu with the Elementor Price Menu Widget.
19. Unfold any elementor element with HappyAddons Elementor unfold widget
20. Toggle your content with the Elementor content switcher widget.
21. 500+ elementor line icons for your elementor sites.
22. 450+ Readymade Elementor Template Kits to Use,
23. Moreover, You Can Copy Happy Elementor Addons Demo Contents Directly from Our [demo site](https://demo.happyaddons.com/) and much more.
24. Officially recommended by Elementor Page Builder! We are now listed on their [official addons page](https://elementor.com/addons/).
25. This Elementor Page Builder Addon is the latest addition to the list of [weDevs](https://wedevs.com/) premium product libraries. **weDevs is famous for reliable after-sales service**.


**WHAT YOU WILL GET IN HAPPY ELEMENTOR ADDONS FREE VERSION**


**48 Free Elementor Widgets Are Available in the HappyAddons Free**

HappyAddons comes with plenty of Elementor Widgets in the free version. And all of the elementor widgets are full of customization. Also, we have created elementor design inspiration for each and every single elementor widget. Let’s have a look at what you will get in our free version of HappyAddons for Elementor:



* **[Card](https://demo.happyaddons.com/elementor-card-widget-demo/)** – Incredibly powerful widget to demonstrate your products, articles, news, creative posts using a beautiful combination of texts, links, badges, and images. Using built-in positioning and offset features you can create eye-candy designs in a twist. \
Our elementor card widget will help you to create mesmerizing card items within elementor widget. You can add custom badge items to the Elementor card widget. Also, you can add images, custom buttons to the Elementor Card widget of the Happy Elementor Addon. Check our elementor card widget from our demo site. If you like the demo design you directly use the card items directly to your elementor website with our live copy feature of HappyAddons Pro. 
* **[Info Box](https://demo.happyaddons.com/elementor-info-box-widget-demo/)** – Our Elementor Info Box widget will help you to create beautiful information boxes using icons, links, and texts and this makes them slick using the built-in positioning features. This Elementor Info box widget is different from our Elementor card widget. Elementor info box widget will allow you to add elementor heading and elementor descriptions and elementor button within it. Also, you will get the flexibility to customize the heading, button, image, or icon of the elementor info box widget. Check the demos of the Happy Elementor Addons info box widget for the Elementor page builder.
* **[Icon Box](https://demo.happyaddons.com/elementor-icon-box-widget-demo/)** – Elementor Icon Box widget is a simplified version of Infobox but comes with powerful display features. Perfect for showcasing interesting information to your users in various styles. HappyAddons elementor icon box widget is easy to customize. Within this Elementor icon box, you will get ‘Icon‘ to set the icon size, add padding, border, box-shadow. You can also add a hover effect to your icon of the Elementor icon box widget. Moreover, you will get the flexibility to add Title‘ so that you can set text type using typography, add text-shadow, text color within the icon box widget for elementor.  Check our elementor icon box widget from our demo site. If you like the demo design you directly use the card items directly to your elementor website with our live copy feature of Happy Elementor Addons Pro. 
* **[Skill Bars](https://demo.happyaddons.com/elementor-skill-bars-widget-demo/)** –  Elemento Skill Bar Widget is an essential building block to showcase user skills, task percentage, required tools, and other progressive information in different ways. Happy elementor addons skill bars elementor widget comes with incredible customizing options to suit your needs. You can use the Team Skill Bars Elementor Widget to create beautiful designs. ‘Text Color’, ‘Level Color’,’ Base Color’ is available in the HappyAddons elementor skill bar widget. By using the coloring option of the Elementor Skill Bars widget you can stand out your skillset from others. This elementor skill bar widget will help you to showcase your different skillset on your Elementor website. Also, help you to increase the credibility of your portfolio. Use the skill bars widget for elementor to stand out yourself in the crowd as there are no design limitations in the Happy Addons Skill bar elementor widget. 
* **[Review](https://demo.happyaddons.com/elementor-review-widget-demo/)** – Showcase your user feedback, reviews, and rating more easily than ever using our review widget. Display user photos, texts, and star ratings. Make them stand out using built-in offsets and positioning features. User reviews and testimonials are so important to build your user's trust for your brand and the HappyAddons Elementor Review widget will be the best option for you to show Reviews on the site without any hassle. What are you getting in the elementor review widget!  You can style your reviews by clicking on the 'Review' option. It is possible to set a maximum rating a user can give, such as 4.8 or even 5. Users can give reviews in stars or in numbers. You can also set the review position whether it should be on top or bottom within the HappyAddons Elementor Review Widget. Also, you can customize the Reviewer image in the Elementor Review Widget. Try Happy elementor addons Review widget for Elementor. 
* **[Image Compare](https://demo.happyaddons.com/elementor-image-compare-widget-demo/)** – Are you a photo-editor, agency, or product designer who often needs to showcase their beautiful works in a form of a before and after slider? The Elementor Image compare widget is perfect for this job. And built-in styling options, vertical and horizontal orientation features can help you design these before-after sections with more creativity. Our image compares elementor widget will help you to compare between your two product images Old Vs New in an amazing way. By maintaining a perfect image resolution, it will be able to detect major changes in the product. Get ready to showcase your product comparison exclusively by using HappyAddons Elementor Image Compare widget.
* **[Gradient Heading](https://demo.happyaddons.com/elementor-gradient-heading-widget-demo/)** – Another gem to create eye candy Elementor headings for your websites. You can apply different gradient styles, angles, opacity, and positions to make them look even better across different device screens to our Elementor Gradient Heading widget. It is the easiest way to add a gradient to your headlines and titles inside of the Elementor page builder. So don’t waste your time creating a custom-coded gradient heading within your Elementor site, use the HappyAddons Gradient Heading widget for Elementor to make an amazing gradient Heading for your elementor site.
* **[Team Member](https://demo.happyaddons.com/elementor-team-member-widget-demo/)** – A perfect elementor widget to showcase your beautiful team in various styles using texts, images, and social links. And just like our other widgets, you will find powerful styling options to make them stand out quite easily. Set your employee name, job title. You can add a short bio of his/her job if you want. Resize your texts using the headers h1 to h6. You can move the image left, right, center using the alignment option. Also you have the option to add social media links with social icons of your team members in the Happy Addons team member widget for Elementor. So you will get the ultimate team member features within elementor team member widget. 
* **[Dual Button](https://demo.happyaddons.com/elementor-dual-button-widget-demo/)** – DualButton widget allows you to add two flexible and trendy action buttons in your sections, in different styles. Usually, elementor buttons don’t have the facility to add additional content like or, but, & type of linker within two elementor buttons. Also, it will help you not to create so many doms for creating simple buttons. Try our elementor dual button widget.  
* **[Number](https://demo.happyaddons.com/elementor-number-widget-demo/)** – Simply beautiful, this widget can help you create stunning number blocks with various styles, look-n-feels that are literally going to blow your mind. Elementor Number widget is familiar to show numbers on websites. It could be anything related to number stat. Also, you will get the flexibility to customize the Elementor Number Widget. This elementor widget is a very lightweight one. So try the number widget for elementor.
* **[Justified Grid](https://demo.happyaddons.com/elementor-justified-grid-widget-demo/)** – Another pro-grade widget that can help you to create a beautiful justified grid. It comes packed with tons of options to make it stand out from the crowd. This Elementor Grid widget will help you to create isotope gallery items within your Elementor site. Also, you can add a hover effect to the justified images of the Elementor Justified Grid widget. 
* **[Testimonial](https://demo.happyaddons.com/elementor-testimonial-widget-demo/)** – Create beautiful testimonial sections with different look-and-feels using the HappyAddons Testimonial widget. Elementor testimonial widget will help you to create a trust for your users. This Testimonial widget for Elementor comes with plenty of customizations. You don’t have to create any custom post types to show a testimonial for your websites. You can manage it from the Elementor editor panel. Also, you can add testimonial providers' avatars and designation to make them more credible for your users. It’s a smart testimonial widget for Elementor. Try Elementor Testimonial Widget to make a trustworthy product or website. 
* **[Logo Grid](https://demo.happyaddons.com/elementor-logo-grid-widget-demo)** – Showcase your clients or products using our Elementor logo grid widget, and display these items with styles. Elementor Logo Grid widget is one of the best Widget HappyAddons for Elementor. This elementor widget will help you to create an amazing logo grid within your Elementor site. And this is a unique item within among elementor addons. You can show your clients logo items in a grid way with the help of the Elementor Logo Grid widget. So try the Elementor Logo Grid widget to showcase your logo items. 
* **[Slider](https://demo.happyaddons.com/elementor-slider-widget-demo/)** – Now you can create sliders with beautiful animations and effects using our Elementor Slider widget. And just like our other widgets, there are lots of customization options for you. This free Elementor slider widget is just an awesome addition to the HappyAddon Elementor widget library. You can create outstanding slider items for free. Within our Elementor Slider widget, you can position your navigation items anywhere in the slider content area. So try this Elementor slider widget for free. 
* **[Carousel](https://demo.happyaddons.com/elementor-carousel-widget-demo/)** – Create interesting images and text carousels using our Elementor carousel widget which comes with a lot of options. Most of the Elementor Addons have the post carousel or WooCommerce product carousel but our elementor carousel widget will help you to create a text carousel or simple image carousel without any hassle in your elementor site. Isn’t it a cool carousel elementor widget? So try this Elementor carousel widget now for free. 
* **[Image Grid](https://demo.happyaddons.com/elementor-image-grid-widget-demo/)** – Simply beautiful, this Elementor widget can help you create stunning number blocks with various styles, look-n-feels that are literally going to blow your mind. HappyAddons Image Grid Elementor widget will help you to show grid images on your Elementor website. This is a simple Elementor Image grid widget. You can use this for creating a simple image grid without leaving your Elementor Editing Panel. Other image grid plugins like modular, Envira image gallery, nextgen image gallery will not allow you to create gallery images within your editing panel. You have to create an image gallery in your wordpress backend of the gallery plugins. But our Elementor Image grid gallery widget will not do this. You have full flexibility to create and customize the gallery images from the editing panel of Elementor. And that’s why it’s the best grid image gallery elementor widget among the third-party elementor addons. Try the happy addons image grid gallery widget for Elementor. 
* **[Step Flow](https://demo.happyaddons.com/elementor-step-flow-widget-demo/)** – HappyAddons Elementor Step flow widget will help you to create an excellent step-by-step visual diagram and instructions using this smart widget. This elementor step flow widget will allow you to change directions, counters and make them look amazing with icons, texts, and colors. Elementor Step flow widget is the best elementor widget to show content on the step flow way. You can add images and text to the step flow widget for the elementor. Also, you can change the typography of the Elementor Step flow widget.
* **[Fun Factor](https://demo.happyaddons.com/elementor-fun-factor-widget-demo/)** – The fun factor elementor widget is a counter widget for Elementor. You can set a counter number on your site. This type of fun factor or counter Elementor Widget will help you to create FOMO for the visitors. Also, it helps to show data of how many clients you have served or if you have a downloadable product and you want to showcase the number of the downloads in the frontend so this fun factor elementor widget or Elementor Counter widget will help you to achieve that. So try this Elementor fun factor widget to show numbers in an animated way on your website. Also, you can add suffix and prefix to your numbers of this Elementor Fun Factor widget. 
* **[Calendly](https://demo.happyaddons.com/elementor-calendly-widget-demo/)** – Schedule meetings without the back-and-forth emails through Calendly. We are happy to integrate this important application into our HappyAddons. As you know calendly is one of the best booking and appointment tools in the market. But the embedding system of the calendly is really tough. But if you use our Elementor Calendly widget you will be able to embed and customize your Calendly meetings in a lucrative way. It’s now become so easy to embed any Calendly Calendars within any elementor website with the help of the HappyAddons Calendly widget for Elementor. It’s a missing piece among all of the Elementor addons. So try the Elementor calendly widget of HappyAddons to create a lucrative booking and appointment calendar for your website. 
* **[News Ticker](https://demo.happyaddons.com/elementor-news-ticker-widget-demo/)** – Want to show updates, popular content, or messages on your website? With the Happy Elementor Addons Content Ticker elementor widget, you can do this at your disposal with great customizability. Usually, the news ticker elementor widgets are used by the news or magazine types of websites. But now the trends have changed. Newstickers can be used for various purposes. The main purpose of a newsticker is to show information consistently. In elementor is tough to manage without any external newsticker plugin. But HappyAddons is here to solve the issue. Now you can create news tickers within your Elementor Editing panel. You don’t have to leave the editing panel anymore while creating a newsticker section for your website. Elementor Newsticker widget by happy addons is here for you. Try this elementor news ticker widget to create amazing newsticker items for your elementor website. This is also a missing piece among all of the elementor addons. 
* **[Social Icon](https://demo.happyaddons.com/elementor-social-icon-widget-demo/)** – Beautifully insert and display your social links onto your webpage using this widget to easily connect with your site visitor by using HappyAddons social icon widget for Elementor. Social icons are essential for a website. You can now add your company or personal social links to your website by using the happy addons elementor social icon widget. This elementor social icon widget will help you to create social credibility. Try happy addons social icon widget for elementor. 
* **[Twitter Feed](https://demo.happyaddons.com/elementor-twitter-feed-widget-demo/)** – Showcase your awesome team decorating in the Twitter feed mode applying various styles, texts, images, and social links. Adding Twitter feeds isn’t such an easy task. But you can achieve it by using the HappyAddons Elementor Twitter feed widget. Just add your Twitter API in this Twitter feed elementor widget you will get plenty of options to make it lucrative.  We have created a few demo designs by using our Elementor Twitter feed widget so that you can get an idea of which type of things you can create with this Twitter feed widget for elementor. It’s one of the best Twitter feed elementor widgets among all of the third-party elementor addons. 
* **[Bar Chart](https://demo.happyaddons.com/elementor-bar-chart-widget-demo/)** – Display bar charts in an animated and customizable bar form essentially in case of imaging different data and other relevant statistical visualizations with using Happy Elementor Addons bar chart elementor widget. This bar chart widget for elementor can help you to show various data. If you are running static sites then this type of data chart elementor widget items might help you to showcase your data in an advanced way. Try HappyAddons bar chart widget for elementor. We have prepared so many demos on the Elementor Bar Chart widget. You can have a look at them. 
* **[360° Rotation](https://demo.happyaddons.com/elementor-360-rotation-widget-demo/)** – Create 360 Degree rotated images for your Products with this elementor 360-degree widget. Flexibility to add auto-rotate or click to the rotation functionality. Also, you can add Magnify Button to Zoom-in your pictures. It’s usually used by the woo-commerce website owners to show the all side view of their products. This 360° Rotated elementor widget will help you to create amazing rotated or animated 360° images. This Elementor 360° Rotation widget will help your users to understand the product perfectly from different angles and help you a bit to get more sales. So try the HappyAddons elementor 360° Rotate widget to create an amazing 360° Rotated image item for your products. 
* **[Data Table](https://demo.happyaddons.com/elementor-datatable-widget-demo/)** – Using a data table on the website is a difficult task if you don’t have any coding ideas or knowledge. However, the elementor data table widget of Happy Elementor Addons will solve this problem. Usually, most of the data table plugins are not allowing you to create tables within the frontend editing panel. The data table plugins navigate you to create tables within their settings panel and give you a shortcode to set it on your desired sections. You can check the Tablepress, ninja tables, and more table plugins in the repository. Most of them don’t have direct integration with the Elementor Page Builder. You have to be an expert to change the default look of the third-party data table plugins. Without the knowledge of HTML & CSS, you cannot do anything. But HappyAddons Elementor data table widget will help you to create a data table within your elementor Editing panel. Also, you don’t need to know CSS or HTML to design our Elementor Data table widget. Moreover, if you use the HappyAddons Elementor data table widget you can add images and icons to your table without any hassle. Check the various demos of the data table widget for Elementor of happyAddons to get a vivid idea of how an awesome elementor data table can be made with this Elementor data table widget. 
* **[Pricing Table Lite](https://demo.happyaddons.com/elementor-pricing-table-widget-demo/)** – Create beautiful pricing tables with lots of customizations and sleek look-n-feel using the Elementor Pricing table lite widget. Usually, we used to use table plugins to create such kinds of pricing tables in the past. But after having Elementor page builder in our WordPress Ecosystems we get a huge opportunity to create stunning pricing tables to manage our products’ pricing pages. But with the Elementor if you want to create a pricing table you have to use so many elementor columns and inner sections. If you use the HappyAddons Pricing table lite widget you will be able to create a stunning pricing table menu without creating so many dom requests. As our pricing table, the lite elementor widget is a single elementor widget. It’s a rare piece of elementor pricing table widget that is missing in other third-party elementor addons widgets lists. We have created several demo designs for our elementor pricing table widget. Check them all from the demo page of the Elementor pricing table widget. 
* **[Flip Box Lite](https://demo.happyaddons.com/elementor-flip-box-widget-demo/)** – FlipBox helps you to deliver messages in a beautiful way with before and after effects. Elementor Flip box widget by HappyAddons will help you to create amazing flip box content for your elementor website. There are several states to flip the content within our elementor Flipbox widget. Check all the demos of the HappyAddons flip box elementor widget. 
* **[Post Tab](https://demo.happyaddons.com/elementor-post-tab-widget-demo/)** – Enable users to present your post in multiple workable tabs ideally useful for grouped and related content if you use the Elementor Post tab widget of Happy Addons for Elementor. This post tab elementor widget is now available in the free version of HappyAddons for Elementor page builder. Post widgets are usually helpful for showing blog posts within your elementor website. You will get full freedom to design your elementor post tab contents. Check the demo content of the Elementor Post Tab widget. 
* **[Post List](https://demo.happyaddons.com/elementor-post-list-widget-demo/)** – List any post elegantly using this elementor widget displaying them in a creative and innovative manner with multiple options to play with. HappyAddons Elementor Post List widget is for displaying your post content in a list view. Usually, this type of post widgets is in the premium version of other third-party Elementor Addons. But you are getting this elementor post list widget for free in the HappyAddons Elementor widget library. So try the free elementor post list widget to display your post content in a list view. 
* **[Taxonomy List](https://demo.happyaddons.com/elementor-taxonomy-widget-demo/)** – This Elementor Taxonomy widget will help you to create a list of posts by sorting categories, tags, post formats. You will get plenty of customization facilities within the elementor taxonomy list widget. It will help your visitors to sort the content in different taxonomy wise. So try our elementor taxonomy list widget for free to help your visitors.
* **[Horizontal TimeLine](https://demo.happyaddons.com/elementor-horizontal-timeline-widget-demo/)** – Design your storyline horizontally using the Elementor Horizontal Timeline Widget by Happy Elementor Addons. It’s absolutely free! Unlike the vertical timeline elementor widget, you will get the opportunity to show your content horizontally with the help of the HappyAddons Elementor Horizontal Timeline widget. You can add images and text within this Elementor Horizontal timeline widget. 
* **[Social Share](https://demo.happyaddons.com/elementor-social-share-widget-demo/)** – No need to buy a social share plugin anymore. Get many of the premium features of social share plugins within the HappyAddons Elementor Social Share widget for free! You can set your social share widget anywhere on your elementor website. You need to just drag the happy elementor addons social share widget for elementor. You have the full freedom to manage this elementor social share widget. You can set color, customization, and typography to the social share elementor widget. This social share widget for elementor will grab the associate link where you have set the elementor social share widget. Try HappyAddons social share widget for elementor and don’t forget to check the demo of the elementor social share widget. 
* **[Event Calendar](https://demo.happyaddons.com/elementor-event-calendar-widget-demo/)** – Are you struggling to incorporate an event calendar on your website with the help of Elementor? Don’t worry; HappyAddons for elementor has added an amazing Event Calendar Widget in the Free Version for you! You can create your own personalized calendar manually or use your Google calendar or the Events Calendar Plugin’s calendar to showcase your events. Team happyaddons for Elementor bring this elementor event calendar widget for you to solve your daily problem. You have the full freedom to design your event calendars within your elementor website. Also if you are managing your event calendar with your personal google calendar and want to embed it within your Elementor site then you should try the Happy Elementor addons event calendar widget to embed your google event calendar. Or if you have plans to create your own custom event calendar then this widget will help you to do that. HappyAddons elementor event calendar widget covers that custom event calendar creation feature too. Before testing this elementor event calendar widget check the demo created by team happy elementor addons.  And this is a great addition to the elementor widget library of HappyAddons for elementor and which is missing in most of the third-party Elementor Addons Elementor widget libraries. 
* **[Image Hover Effect](https://demo.happyaddons.com/elementor-image-hover-effect-widget-demo/)** – If you want to add lucrative hover effects to your website’s images, you can try HappyAddons elementor Image Hover Effect Widget. This elementor image hovers effect widget allows you to add 20+ stunning hover effects to your photos. Start adding attention-grabbing images easily by using the image hover effect for elementor of Happy Elementor Addons. You have full freedom to customize the Elementor Image Hover Effect widget of Happy Elementor Addons. If you want to add visitor attention then the image hovers effect widget will be essential to your elementor widget library. Before testing the elementor image hover effect you can check the demo of the Image hover effect widget for the Elementor page builder.
* **[Animated Link](https://demo.happyaddons.com/elementor-animated-link-widget-demo/)** – Are you wondering about increasing the click-through rate of your website’s links? Grab your visitor’s attention by adding different effects to your links using the Happy elementor addons Animated Link widget for Elementor. This Elementor Animated link widget has plenty of hover effects for your elementor website’s links. Just choose the best suitable one from the elementor editing panel of the Animated link elementor widget. You can check Happy Elementor Addons demos for the elementor animated link widget before testing this elementor widget.
* **[Mailchimp Widget](https://demo.happyaddons.com/elementor-mailchimp-widget-demo/)** – Now you can create lucrative Mailchimp forms with HappyAddons Mailchimp Widget for Elementor. Usually, you don’t have the opportunity to add Mailchimp form directly to your elementor landing pages. But now the Happy Elementor Addons Mailchimp widget will help you to create an amazing MailChimp form within your elementor landing pages. And you can set tags for your MailChimp subscribers which are missing in other third-party elementor addons Mailchimp Elementor widget. Also, you can select the list from the elementor editing panel of the MailChimp widget for elementor. No bar in elementor Mailchimp form widget customization. You don’t need elementor pro to use happy elementor addons Mailchimp widget for elementor. With the Elementor Free version and the free version of the Happy Elementor addons, you can easily create a newsletter subscribe form or newsletter subscribe bar for your elementor site. No hassle in the API integration of the happy addons for the elementor Mailchimp widget. Team Happy Elementor Addons add a dedicated page for integrating the API credential. Just paste your MailChimp form API key to the Happy Elementor Addons Mailchimp Widget’s API input field of the backend page of the HappyAddons Credential Page. And all set to use the Mailchimp form elementor widget. Plenty of customization is available in the Mailchimp form for Elementor Page Builder. Before testing the Elementor Mailchimp form widget please check the demos created by the Team Happy Elementor Addons. 
* **[Content Switcher](https://demo.happyaddons.com/elementor-content-switcher-demo/)** – Happy Content Switcher Elementor widget allows you to toggle Elementor sections, pages, or texts easily. This is a masterpiece created by the team Happy elementor addons. Elementor content switcher widget will help you to show any kind of toggle content within your elementor website. You can even add any elementor widgets, elementor templates in the content switcher widget. It’s basically used to toggle two different types of content. Like if you have two types of pricing menu like annual pricing menu and the lifetime pricing menu then you can use the Happy elementor addons content switcher elementor widget to show the two different pricing tables within the same section of your elementor website. As you have full freedom to add any kind of elementor template within the elementor content switcher widget then there is no limitation of customization. And this elementor content switcher widget is the unique addition to the Happy Elementor Addons free pack which is missing in the other third-party elementor addons free elementor widget pack.  
* **[Image Stack Group](https://demo.happyaddons.com/elementor-image-stack-group-demo/)** – Sometimes we have to show images in a stack group format to create an eye-catchy look. But it’s so tough to create a single stack group of images with Elementor. But with our Elementor Image Stack Group widget, you can easily create an image stacked group within Elementor. You can get the Elementor Image Stack Group widget in the free version of Happy Elementor Addons. Check the demo of the elementor image stack group widget created by the happy elementor addons. 
* **[Creative Button](https://demo.happyaddons.com/elementor-creative-button-demo/)** – Are you wondering about creating an outstanding, eye-catching look by adding exclusive button styles & effects to your website? Create a marvelous Call To Action through HappyAddons Creative Buttons Elementor Widget and redirect visitors to the right place. There is now a limitation to creating amazing buttons for your Elementor website. Also, the team happy elementor addons added the magnetic effect to the elementor creative button. So that you can grab your elementor website’s visitor’s attention to click the elementor creative button. And don’t forget to check the demo of the elementor creative button widget, created by the team happy elementor addons. 
* **[Image Accordion](https://demo.happyaddons.com/elementor-image-accordion-demo/)** – HappyAddons Image Accordion widget for Elementor comes with interactive design looks. You can create unique accordions for images. It will help you keep your users longer on the website. Sometimes you will need to show some amazing interactive image accordions to your elementor website to create a wow effect for the visitors, then the Happy Elementor addons image accordion elementor widget will be the life savior for you. As you can add an amazing effect to the images by using the happy elementor addons image accordion elementor widget. Don’t forget to check the demos of the Elementor Image Accordion, created by the team Happy Elementor Addons.  And after that try Happy Elementor Addons Image Accordion Elementor Widget.
* **[PDF View Elementor Widget](https://demo.happyaddons.com/elementor-pdf-view-widget-demo/)** - If you are looking for a PDF embedder or PDF Viewer WordPress plugin for your website to embed your PDF files, you are in the right place. Happy Elementor Addons comes with the ultimate PDF embedder solution for you. We have added Elementor PDF View Widget, a new Elementor widget in the Happy Elementor Free Version 3.3.1. We are the pioneer in the Elementor Addons community who have added a PDF view Elementor widget in the Elementor Widget Library. Using the Happy Elementor Addons PDF View widget for Elementor, you can embed or view PDF files from external links or upload them directly to your website as PDF Media File. Also, in this Elementor PDF View widget, you will get plenty of customization options. Now you can show Resume PDF, Invoice PDF, Ebook PDF version, Magazine PDF version, and more with the help of the PDF View Elementor Widget by Happy Elementor Addons. 
* **[Contact Form 7](https://demo.happyaddons.com/elementor-contact-form-7-widget-demo/)** – This utility widget helps you to integrate existing forms built using the CF7 plugin across your web pages without spending too much time. It’s tough to manage the default contact form 7 without using any CSS. But Team Happy elementor Addons added all kinds of designing facilities to the contact form 7. Happy Addons for elementor added a free elementor contact form 7 widget to the elementor widget library. You can easily embed your contact form 7 at any place on your Elementor website. Also, you have the facility to customize the contact form 7 elementor widget. You don’t need the knowledge of CSS to customize your contact form 7 forms if you use the Happy Elementor Addons contact form 7 widget. And it comes in the free version of the HappyAddons for elementor. 
* **[Caldera Forms](https://demo.happyaddons.com/elementor-caldera-forms-widget-demo/)** – This widget can help you to display your caldera forms to display on your web pages designed with Elementor. By default, the design customization of the caldera form is quite tough. You have to be an expert in CSS. But team Happy Elementor Addons solve the problem. Now you can customize your caldera form by using the Happy Addons caldera form elementor widget. It’s free to use. Before using elementor caldera form widget you can check the demos created by team Happy Elementor Addons. 
* **[weForms](https://demo.happyaddons.com/elementor-we-forms-widget-demo/)** – Designed forms using the weForms plugin and looking for a way to display those on your Elementor powered pages? This is the answer to that. You can now use the Happy elementor addons weForms widget for elementor to customize your weForms forms without leaving your elementor website. Check the demos of the Elementor weForms widget created by the team Happy Elementor Addons. 
* **[Ninja Forms](https://demo.happyaddons.com/elementor-ninja-form-widget-demo/)** – Use this widget to embed forms created using Ninja Forms to display seamlessly on your web pages. Various styling options will help you to look at them even better. Ninja Forms is one of the popular form builder plugins. But you have to pay extra for having the customization feature in the default version of Ninja forms. But the team Happy Elementor Addons comes with an easy solution for Ninja Forms users. You will get a Ninja form elementor widget for free in the Happy Addons for elementor. We have added every possible customization facility to the Elementor Ninja Forms widget. You can check the demo from the happy elementor addons demo page. 
* **[WPForms](https://demo.happyaddons.com/elementor-wpform-widget-demo/)** – Use this widget to embed forms created using WPForms to display seamlessly on your web pages. Various styling options will help you to look at them even better. WP Forms has now become the most popular form builder in the WordPress Community. The WPforms became popular due to its vast feature and customization facility. But the design customization is also a limitation for the WP Forms users. But the team happy elementor addons bring a free solution for the WP forms users. You will get a free WP forms elementor widget in the free version of the Happy Addons for elementor. This Elementor WPforms widget will help you to design your forms to the next level. Don’t forget to check the demos of the WPforms elementor widget created by the team Happy Elementor Addons. 
* **[Gravity Forms](https://demo.happyaddons.com/elementor-gravity-form-widget-demo/)** – While using Gravity forms, you may want to change the appearance of the form fields. With the Happy Addons, you can spruce up your Gravity forms like a pro. But it’s already a premium plugin. But the design customization is also challenging. That’s why the happy elementor addons bring a free solution to help the Gravity forms user base. You can use the Gravity forms elementor widget created by team Happy Elementor Addons. This elementor gravity form widget will help you to reshape your default form widget without any hassle. You can check the demos for Gravity Forms Elementor Widget created by the team Happy Elementor Addons. You will get an idea of what you will get in the free version of the HappyAddons Gravity forms elementor widget. 
* **[WP Fluent Forms](https://demo.happyaddons.com/elementor-fluent-form-widget-demo/)** – Easily customize and use Fluent Forms using this super intuitive widget. The WP Fluent Forms are now becoming very popular in the WordPress community. But the customization of the fluent forms is also difficult. You have to be an expert in CSS as well. But Team Happy Elementor Addons also brings light to this issue. You can customize your WP fluent forms with the free elementor widget of the WP Fluent Forms. No need to be an expert to customize the Elementor Fluent Form widget of Happy elementor addons. We have also made demos for the Fluent Forms Elementor widget. Check the demos of the WP Fluent Forms Elementor widget. 
* **[Comparison Table](https://demo.happyaddons.com/elementor-comparison-table-widget-demo/)** - The comparison table will help your site visitors to buy your product, sign up for membership, contact, or just request a quote. Are you wondering about creating comparison tables for your affiliated products, gadgets, features, services, or anything related to your website? Try HappyAddons new comparison table widget for Elementor. It’s available in the free version of HappyAddons for Elementor.

**20+ Free Elementor Enhancement Features Are Available in the Happy Elementor Addons Free**

HappyAddons not only comes with extendable elementor widgets but also it has some cool features which help you to increase your web designing skill. You will get 20+ exclusive Elementor features in HappyAddons Free.

**[Happy Templates](https://happyaddons.com/template-importer/)** – Finally, we are happy to announce that we are introducing the Happy Elementor Template import feature within our Happy Elementor Addons. Initially, it comes with almost 500 ready-made elementor templates. We will continuously improve our template library. Both of our Free and Pro users can use happy templates. Templates are labeled in two tags, Pro and Free. To import premium templates you will need the [HappyAddons Pro](https://happyaddons.com/pricing). The template import feature works like Elementor Template importing feature. Additionally, you can check the previews in three device viewport; Desktop, Tab, Mobile.

The team Happy Elementor Addons comes with Full Page Elementor Templates. You will now get plenty of Elementor Full page templates. Elementor Page templates are easy to use. Just import it and use it within your Elementor Website and do some little bit customizations. You will get Elementor business website page templates, Elementor contact page templates, Elementor Fitness Page Templates, Elementor Black Friday Deal Page templates, Elementor Cyber Monday Page Templates, Elementor Halloween Page Templates, and more misc full elementor page templates. We are planning to bring an Elementor Template kit pack in the future. Stay connected with Happy Elementor Addons. 

**[Happy Shape Dividers](https://happyaddons.com/happy-shape-divider/)** – If you want to get some unique shape dividers within your elementor shape divider you can use our HappyAddons Shape Dividers for Elementor. Initially, you will get 18+ new shape dividers. Team Happy Elementor Addons brings this new feature among all of the Elementor Addon plugins. We are the pioneer in adding different elementor shape dividers to the default elementor shape dividers library to give the elementor users some extra shape dividers for elementor. Reshape your Elementor Pages with the new happy Elementor shape dividers. It’s an extra addon to elementor shape dividers. Don’t miss the chance to reshape the shape dividers of your elementor pages. 

**[Happy Tooltip](https://happyaddons.com/happy-tooltip/)** – You can add tooltips to any elements of your Elementor website with the HappyAddons Elementor advanced tooltip feature. Add images, GIFs, Background images to your Elementor tooltips with the help of the Happy Elementor Advance Tooltip feature. This tooltip elementor module by Happy elementor addons broadens a new way to create amazing tooltips within your elementor website. You don’t need any extra third-party tooltip plugin from the WordPress repository to add Tooltips to the elementor elements of your elementor website. You don’t have to bother with the tooltip shortcuts to add happy elementor tooltips to your elementor website. You can add Elementor tooltips from the editing panel of your elementor website. You don’t have to bother with any kind of back and forth challenges like other third-party tooltips plugins. Just select the elementor widget or elementor section where you want to add your tooltip contents and do it from your elementor editing panel. Team HappyAddons for Elementor added two types of behavior on tooltips of HappyAddons. You can show elementor tool tips on click or on hover. Also, you will get plenty of tooltip animations in the Happy elementor addons tooltip feature. And all the awesome tooltip features come with the free version of Happy Elementor Addons. Don’t miss out on the chance to use the best elementor tooltip feature. it will work with any third-party elementor addons like Elements Kit, plus addons, essential addons, premium addons, and more elementor third-party addons Elementor widgets.

**[Elementor Equal Heights](https://happyaddons.com/equal-height-feature/)** – By default you cannot set the equal column heights to your elementor columns. But from now you can set equal heights to your Elementor Columns, widgets without using zero coding knowledge by using the Elementor Equal Heights feature of Happy Elementor Addons. Usually, Elementor Equal Heights requires when you have different lengths of contents on the elementor columns. And there is no easy way to fix this. You have to add more space or do some CSS stuff. But with the HappyAddons Elementor Equal Heights feature, you can fix the issue within the twinkle of your eyes. So try the Happy elementor addons Elementor Equal Heights for free. 

**[Text Outline](https://happyaddons.com/text-outline/)** – With this Elementor Text Outline feature you can add an exterior border around each character of your text or Heading lines. You can create Neon Text Effect, Parallax Heading Effect, Stroke Heading Effect and much more. You can also apply this feature in the Elementor’s Default Heading Widgets. Here is the list of widgets within which you will get this text outline option,

– Elementor Heading Widget

– Elementor Page Title Widget

– Elementor Site Title Widget

– Elementor Post Title Widget

– Elementor Product Title Widget

– Elementor Animated Heading Widget

– HappyAddons Gradient Heading Widget

Here are some design inspirations for you. **[Demo](https://demo.happyaddons.com/text-outline/)**

If you are looking for the awesome handy tool (Elementor Text Outline)to make a difference in your elementor website then don’t miss out on the chance to try it free as this Elementor Text Outline feature comes with the free version of the Happy Elementor Addons. And the Elementor Text outline feature is a very lightweight Elementor feature to create amazing design aspects within your elementor website. 

**[Background Overlay](https://happyaddons.com/background-overlay-demo/)** – The Elementor Background overlay extension will allow you to add images, colors, and icons behind an Elementor widget. You can add background overlay to any Elementor widget. Actually, you can add background overlay to the Elementor Sections and Columns but it’s quite tough to add Background overlay to the elementor widgets. But now with the help of the Happy elementor addons elementor background overlay extension, you can add a different look to your elementor widgets. Interestingly, it will work with any third-party elementor addons like Elements Kit, plus addons, essential addons, premium addons, and more elementor third party addons Elementor widgets.

**[Happy Icons](https://happyaddons.com/happy-icon/)** – This will help you embellish your web page with an army of free happy elementor line icons. To do so, you have to choose a widget that supports happy elementor line icons. Currently, the custom fonts library contains 500+ icons. Usually, you will get font awesome icon library with your elementor icon pack. But the line icons are now trendy. You can add line icons to every possible icon-supported elementor widget. HappyAddons elementor line icons come with the free version of Happy Elementor addons. So that you can use these Happy line icons to HappyAddons free and Happy elementor addons pro. It will reduce your pain to upload SVG icons each and every time. Don’t miss out on the chance to make your elementor site a different one from the regular font awesome using Elementor Website. 

**[Managing Column Order on Mobile Responsive Mood ](https://happyaddons.com/happy-column-control/)** – Your designed elementor web page may contain some columns that may require reorder in the mobile device view. By using the Happy Elementor Addons, you can rearrange the order of the column. It’s very easy to use. You don’t need any extra knowledge to order your columns on mobile and tablet devices. Actually, you have to just set the number chronologically to the column ordering feature of the HappyAddons. It will help you to get the desired column order in the small screen of the elementor sites.

**[Manage Column Width by Adding Pixels](https://happyaddons.com/happy-column-control/)** – You can control the column width of your widgets with percentage parameters in Elementor. However, sometimes, you need to adjust the column width to meet your design aesthetics. The Happy Elementor Addons will let you do so with ease.

**[Happy Clone](https://happyaddons.com/happy-clone-demo/)** – While designing with Elementor, you may need to duplicate pages or posts from the finder of Elementor Page Builder by using the buttons (CMD/CTRL + E). Surprisingly, you can copy pages and posts lightning-fast from the Elementor finder using the Happy clone feature. Also, HappyAddons elementor Happy Clone or duplicator feature will help you to duplicate your posts and pages. You don’t need any third-party duplicator plugin to duplicate or clone your page and posts. And interestingly, this handy Happy Elementor Duplicator or clone feature comes with the free version of the happy elementor addons. So try the Happy elementor clone or duplicator extension to duplicate your posts and pages. 

**[Fixed Size Controls in Elementor Button Widget](https://happyaddons.com/docs/happy-addons-for-elementor/happy-features/fixed-size-controls-in-elementor-button-widget/)** – Sometimes, you may need to make perfectly circular-shaped buttons in Elementor. With this free feature, you can do that by just setting a fixed size, that is, by specifying an equal height and width of the Elementor Button widget.

**[Grid Layer](https://happyaddons.com/happy-grid-layout-demo/)** – Maintain proper alignment of your page’s elements. Enjoy full flexibility while setting your grid color, width, and position of your grid layout. Btw it’s not the grid system. It’s actually a design system to create perfectly aligned designs for your elementor website. If you are familiar with other designing tools like Figma, Adobe XD, Adobe illustrator, or sketch you will get the same kind of design grid layer system within your elementor editing panel of your elementor website. 

**[Wrapper Link](https://happyaddons.com/wrapper-link-feature-demo/)** – No limitation on adding links to specific areas of your elementor column, sections if you use Wrapper Link of HappyAddons for elementor. Use the Wrapper Link feature to insert links to any column, section or any other place you want. So don’t miss out on the chance to use the Happy Elementor Addons Elementor Wrapper link module or elementor extension to add a custom wrapper link to any elementor column or elementor section of your elementor website. So wrapper links for elementor will be helpful to increase the click rate of any content of your elementor website. There is no limitation to add wrapper link to any elementor widgets, third party elementor addons widgets too. 

**[Floating Effects](https://happyaddons.com/elementor-floating-effect-demo-2/)** – Now you can create stunning animations for any Elementor widget using Floating Effects. Translate, Rotate, or Scale Imagination is the limit! HappyAddons floating effect will help you to Translate, Rotate or Scale any elements and elementor widgets without using CSS directly. Don’t miss the chance to make eye-catchy design elements to your WordPress elementor website. 

[youtube https://www.youtube.com/watch?v=LmtacsLcFPU&ab_channel=HappyAddons]

### Floating Effects used for Space effect illustration:

With the help of the Happy elementor addons floating effect extension, you can create this kind of amazing Space effect.

[youtube https://www.youtube.com/watch?v=F33g3zqkeog&ab_channel=HappyAddons]

**[CSS Transform](https://happyaddons.com/elementor-css-transform-demo-3/)** – Another missing piece, a great enhancement over core Elementor that works seamlessly with every widget. You can now apply various CSS transforms like translate, rotate, scale and skew without any limitations within any Elementor Widget also with any other third-party elementor addons. It’s a global feature of elementor created by Happy Addons for elementor. Don’t miss the chance to use the Happy Elementor addons CSS transform elementor module to create an extraordinary look for your elementor website. 


### **PRESENTING THE ALL-EXCLUSIVE ElEMENTOR WIDGETS & FEATURES HAPPY ELEMENTOR ADDONS PRO**

The Happy Elementor Addons ships not only with some unique premium features but also with premium widgets. The premium features are 100% unique and exclusive and the premium widgets are there to give you professional assistance to craft any design of your webpage.

[youtube https://www.youtube.com/watch?v=QwJrFMtfO2U&ab_channel=HappyAddons]

_Introducing Happy Addons Pro (Check What You Will Get in the Pro Version of Happyaddons)_


### 50 PREMIUM ELEMENTOR WIDGETS OF HAPPY ADDONS FOR ELEMENTOR (PRO)

If you are still craving more Elementor widgets, then the following premium elementor widgets are there to quench your thirst. The best part is that you can copy and paste the design source code so you won’t have to make any design from scratch. Let’s explore the world of Happy Elementor Addons Pro Widgets:



* **[Advanced Slider](https://demo.happyaddons.com/elementor-advanced-slider-widget-demo/)** – Bored with your typical elementor sliders? Try our advanced slider for Elementor. Create mesmerizing slides within your Elementor Sites using our Advanced Slider. As you can add premade sections to your slides of the Happy elementor addons elementor advanced slider. So you have the full freedom to design any kind of design within the Happy Elementor Addons elementor advanced slider widget. It comes with the premium version of HappyAddons for Elementor. 
* **[Happy Mega Menu](https://demo.happyaddons.com/elementor-happy-mega-menu-widget-demo/)** – Struggling with large-scale menu items? Happy Mega Menu is the best solution to your problems. You can create mega menus like Adidas, Dribbble, Puma, Invision, etc. Megamenus is a game-changing item for websites. As you can create eye catchy menu items with the megamenu of Happy Elementor Addons. The Elementor Megamenu widget will help you to achieve any type of elementor megamenus which is quite impossible with the default elementor menu items. Also, you can use our Happy elementor menu widget to design a simple elementor nav menu for your elementor website. So don’t miss the chance to have a powerful elementor mega menu in your elementor widget package. Before buying the happy elementor addons to get the happy elementor mega menu in your element pack we like to request you to have a look into the demo designs for the Happy mega menu widget for elementor.  
* **[One Page Navigation Widget](https://demo.happyaddons.com/elementor-one-page-navigation-widget-demo/)** – HappyAddons for Elementor’s one page navigation elementor widget will help you create lucrative one page nav contents for your site. It has 9 design controls with a smooth scrolling option. You can show any kind of design within the one page nav elementor widget created by Happy Elementor Addons. This One Page Navigation Elementor Widget is usually used to show multiple contents within one page with a floating navigation menu. Try Happy Elementor Addons one page navigation elementor widget. 
* **[Unfold Widget](https://demo.happyaddons.com/elementor-unfold-widget-demo/)** – You can organize and save space on your webpage with HappyAddons Unfold Elementor Widget. This Elementor Unfold widget will help you create interactive content along with neat and clean Elementor web pages. Moreover, you can unfold the content with click or mouse hover action in your elementor website. Team Happy Elementor Addons has created amazing Elementor unfold widget demos for you. So before trying the premium elementor widget we like to request you to check the demos created by the team happyaddons for elementor. 
* **[Off-Canvas Content or Menu Widget](https://demo.happyaddons.com/elementor-off-canvas-content-demo/)** – Happy Elementor Addons Elementor off canvas navigation content or menu or off canvas nav menu widget will give you the freedom to create any kind of off canvas contents or offcanvas menu items for your Elementor websites. This Off canvas content or menu elementor widget is also popular as flyout elementor menu widget. You can set any kind of flyout menu items or off canvas menu widget for elementor website. Try Happy elementor addons off canvas content or off canvas menu elementor widget. 
* **[Feature List](https://demo.happyaddons.com/elementor-feature-list-widget-demo/)** – You can display your product features using different styles using the Elementor feature list widget. As a bonus, you can also customize each and every predefined design of the Elementor feature list widget. Check the demos of the Feature list elementor widget of Happy Elementor Addons. It’s available in the pro version of HappyAddons for Elementor. 
* **[Pricing Table](https://demo.happyaddons.com/elementor-pricing-table-widget-demo/)** – This one-of-a-kind elementor widget will allow you to create any kind of pricing table under the sun. As a surprise, you can use gradient background, oval-shaped button, font awesome icons, background fill color, different heights, dark mood, and so on within the Elementor Pricing Table widget of Happy Elementor Addons. This elementor pricing table widgets can be used within WooCommerce or EDD (Easy digital downloads) managed websites. You can design any kind of pricing table content within your elementor website without using any table builder plugins or any third party pricing table WordPress plugin. You can manage this elementor pricing table within the elementor editing panel. Also, you can add badges, tooltips, and more within the Happy Elementor Addons pricing table elementor widget created by HappyAddons for Elementor. 
* **[Flip Box](https://demo.happyaddons.com/elementor-flip-box-widget-demo-2/)** – This exquisite elementor flip box widget will help you show different messages or texts at the time before and after a user hover on a certain element. Just like the other elementor widgets, you can customize this with background image, gutter, and circular arrow navigation on both sides. Team Happy elementor addons added the 3d flip box design within the HappyAddons Elementor Flip Box widget. This Elementor flip box widget is in the Happy Elementor Addons Pro version. Also, team Happy Elementor Addon has created so many demos for the flip box elementor widget. 
* **[Advanced Heading](https://demo.happyaddons.com/elementor-advanced-heading-widget-demo/)** – With the Elementor Advanced Heading useful elementor widget you can create beautiful heading designs for the headline text of your Elementor Website. Like the other Elementor widgets, you will get a bunch of free customization options for different sections of the texts. With this elementor heading widget, you can do massive customization in your elementor website. Also the team happy elementor addons added elementor presets to do quick go editing facility of the Advanced elementor heading widget. Also, you can check the demos of the Elementor Advance heading widget created by team Happy Elementor Addons. 
* **[Hover Box](https://demo.happyaddons.com/elementor-image-hover-box-widget-demo/)** – Give boring images lives by adding dynamic animated texts with this nifty little tool Elementor Hover Box Widget. You can display texts with the Hover Box elementor widget right after a user hovers an image. The Elementor Hover Box widget is quite different from regular elementor hover box items. Happy Elementor Addons bring this cool elementor hover box widget for you. Check the demo of the elementor hover box widget created by HappyAddons for elementor. 
* **[Team Carousel](https://demo.happyaddons.com/elementor-team-carousel-widget-demo/)** – Present your team members with beautiful carousels that include social profile buttons, arrow icons, and great customizability by using the Happy Elementor Addons team carousel elementor widget. You can do lots of design customization within the Elementor Team Carousel widget. Also, it’s the best possible way to show team members within a single section of elementor. 
* **[Scrolling Image](https://demo.happyaddons.com/elementor-scrolling-image-widget-demo/)** – Using the elementor scrolling image widget, you can show your products or services in a way that slides horizontally or vertically. You can also create a stunning photo gallery with this awesome scrolling elementor widget within your elementor site. Check the demos created by Happy Elementor Addons of the Elementor Scrolling image widget. 
* **[Advanced Tab](https://demo.happyaddons.com/elementor-advanced-tab-widget-demo/)** – This Elementor widget will enable you to show your content by creating advanced tabbed content sections using full-controlled customizations. You can also use other Elementor widgets inside the tab. As you will get the option to add a custom-made elementor section into the Happy Elementor Addons Advanced Elementor Tab widget. This Elementor Advanced Tab elementor widget is mainly for showing tabbed contents within the elementor single section. So don’t miss the chance to create elementor tabbed content with the help of the Happy Elementor Addons Elementor Advanced Tab widget.
* **[Advanced Accordion](https://demo.happyaddons.com/elementor-advanced-accordion-widget-demo/)** – Just like the Advanced Tab Elementor widget, if you want to provide your user with extra information using a collapsing effect in different directions, then this is the elementor widget you should go for. In the Elementor Advanced Accordion widget, you can use any premade sections of the elementor. Show advanced content within your Elementor Accordion elementor widget. You don’t need any accordion plugin to create an accordion for your WordPress website. Use the Elementor Advanced Accordion Widget to add accordion to your elementor website. 
* **[Testimonial Carousel](https://demo.happyaddons.com/elementor-testimonial-carousel-widget-demo/)** – The Elementor Testimonial Carousel widget will provide you with a great way to showcase the recommendations of your customers. You can also control the carousel’s movement using various flexible styles for your Elementor Website. Team Happy Elementor Addons also created amazing demos for the Elementor Testimonial Carousel widget. So try the testimonial carousel elementor widget. 
* **[Logo Carousel](https://demo.happyaddons.com/elementor-logo-carousel-widget-demo/)** – Unleash your design creativity with this beautiful logo carousel elementor widget and showcase your partners and products using vertical or horizontal motion created by Happy Elementor Addons. This Elementor Logo carousel widget will help you in many ways to showcase your clients’ logo or product logo within your elementor website. Check the demo elementor designs of the logo carousel elementor widget now created by the team Happy Elementor Addons. After checking the demos of the elementor logo carousel widget then but the Happy Elementor Addons premium version. 
* **[Animated Text](https://demo.happyaddons.com/elementor-animated-text-widget-demo/)** – This Elementor Animated text widget is pretty useful to make your text stand apart from the crowd applying smart animations within your elementor website. You can customize the cool animation effects with a variety of flexible styles of the Animated Text Elementor Widget. Try the demos of the Happy Elementor Addons’ Animated Text elementor widget. Then buy HappyAddons for elementor. 
* **[Timeline](https://demo.happyaddons.com/elementor-timeline-widget-demo/)** – Tell your story in the precise and the smartest way using this gorgeous tool Elemntor timeline widget. This time line widget for elementor will help you to achieve an amazing design within your elementor website. Your visitors will get to know everything about the history of your product or company through a bird’s eye view if you use the Happy Elementor Addons timeline widget for elementor. Showcase your story or company history in a precise and elegant way using a powerful and advanced Timeline Widget Addon for Elementor. Using this timeline elementor addon you can create a beautiful timeline with a few clicks. 
* **[Instagram Feed](https://demo.happyaddons.com/elementor-instagram-feed-widget-demo/)** – The elementor Instagram feed widget will pave the way to dynamically show you your beautiful Instagram photos seamlessly on your elementor website page. Users can interact with your photos and leave a comment. Usually, it’s tough to add the Instagram feed to any website. People used to use the smash balloon social feed plugin to add the Instagram feed to their website. The smash balloon is highly pricey for the simple task. But now with the help of the Happy Elementor addons Instagram feed widget for elementor you can easily add your elementor website. You don’t have to spend extra money on social feed plugins like smash balloon. This Instagram feed elementor addon widget created by the team happy elementor addons will help you to add the Instagram feed to your elementor website within a few clicks. Also, you can set the caching time of the feeds of your Instagram profile of the HappyAddons Instagram Elementor widget. 
* **[Advanced Toggle](https://demo.happyaddons.com/elementor-advanced-toggle-widget-demo/)** – Similar to the Elementor Accordion widget, this Elementor Advanced Toggle widget will allow you to create a collapsible container area that will enable the user to show and hide items provided that the user clicks on it. The team Happy Elementor addons have created amazing demos for the elementor advanced toggle widget. So check the demos from the Advanced Toggle elementor widget and buy the happy elementor addons premium plan if you like it. 
* **[List Group](https://demo.happyaddons.com/elementor-list-group-widget-demo/)** – With this incredibly handy elementor list group widget, you can craft beautiful lists. You can also apply advanced styles to give the appearance of the items just like the way you want it with the Elementor list group widget. We have added demo designs for the Elementor List Group widget. 
* **[Countdown](https://demo.happyaddons.com/elementor-countdown-widget-demo/)** – This Elementor countdown widget eye-catching widget will let you set a countdown clock which you can use to show the launch time of your website or prod the customers to take a particular action showing remaining time. This elementor count down widget is created by team Happy Elementor Addons.
* **[Source Code](https://demo.happyaddons.com/elementor-source-code-widget-demo/)** – While writing docs or tutorial posts, you can use this widget to skillfully show codes to your visitors so that they can copy and paste them anywhere on the page at their disposal. Use the Source code elementor widget created by team Happy Elementor addons.
* **[Promo Box](https://demo.happyaddons.com/elementor-promo-box-widget-demo/)** – Promote anything in a more lucrative way with the promo box elementor widget of Happy elementor Addons. And clearly stay ahead in the competition
* **[Hot Spot](https://demo.happyaddons.com/elementor-hot-spot-widgets-demo/)** – Another power-packed elementor widget that can help you create incredible accordions in styles created by team Happy Elementor addons. It’s a powerful elementor hot spot widget rather than the default elementor hot spot widget.
* **[Price Menu](https://demo.happyaddons.com/elementor-price-menu-widget-demo/)** – Display your food menu list with or without price in a decent and creative way with this full flexible widget elementor price menu widget created by team happy elementor addons. 
* **[Business Hour](https://demo.happyaddons.com/elementor-business-hour-widget-demo/)** – This elementor business hour widget will help you show the business hours in a tabular form. Your customers will get to know when your business is open or closed. Try Happy elementor addons business hour widget. 
* **[Line Chart](https://demo.happyaddons.com/elementor-line-chart-widget-demo/)** – Visualize your data in different ways; each of them animated and customizable with the elementor line chart widget which is created by Happy Elementor Addons. Check the demo of the line chart elementor widget.
* **[Pie & Doughnut Chart](https://demo.happyaddons.com/elementor-pie-doughnut-chart-widget-demo/)** – Pie & donut chart elementor widget is to visualize your data in different ways; each of them animated and customizable created by team happy elementor addons. 
* **[Polar Area Chart](https://demo.happyaddons.com/elementor-polar-area-chart-widget-demo/)** – Polar Area chart elementor widget is to Visualize your data in different ways; each of them animated and customizable created by team happy elementor addons.
* **[Radar Chart](https://demo.happyaddons.com/elementor-radar-chart-widget-demo/)** – Radar chart elementor widget is to visualize your data in different ways; each of them animated and customizable created by team happy elementor addons.
* **[Facebook Feed](https://demo.happyaddons.com/elementor-facebook-feed-widget-demo/)** – Show the feed of your Facebook page on your website in a different and creative way through the elementor Facebook feed widget created by happy addons and it’s the best addon to the elementor widget library. 
* **[Twitter Feed Carousel](https://demo.happyaddons.com/elementor-twitter-feed-carousel-widget-demo/)** – Showcase your awesome team decorating in the Twitter feed mode applying various styles, texts, images, and social links with the help of the Twitter feed carousel elementor widget created by Happy Elementor addons. 
* **[Breadcrumbs](https://demo.happyaddons.com/elementor-breadcrumb-widget-demo/)** – Visualize your breadcrumbs in different ways; each of them is customizable with the help of the Bread Crumbs elementor widget created by Happy Elementor addons. 
* **[Sticky Video](https://demo.happyaddons.com/elementor-sticky-video-widget-demo/)** – From now, you can set sticky videos with the HappyAddons sticky video widget. Also, you will get plenty of options to manage your videos in an advanced way with the help of the sticky video elementor widget created by Happy Elementor addons. 
* **[Advanced Data table](https://demo.happyaddons.com/elementor-advanced-datatable-widget-demo/)** – Manage Your Table Data with Google Sheet, Table Press, Import from CSV, Local Database with the help of Advanced data table elementor widget created by Happy Elementor addons. 
* **[Modal Popup](https://demo.happyaddons.com/elementor-modal-popup-widget-demo/)** – Create click-triggered Popups to grab and collect various information from the visitors with the help of the Modal popup elementor widget created by Happy Elementor addons. 
* **[Single Image Scroll](https://demo.happyaddons.com/single-image-scroll-widget-demo/)** – Facing difficulties while presenting long images like web page screenshots, panorama shots, etc to your portfolios? From now on you can showcase long images by using the Happy elementor addons Single Image Scroll elementor widget.
* **[Post Grid](https://demo.happyaddons.com/elementor-post-grid-widget-demo/)** – Scale your blog archive page with the Happy Elementor Addons Post Grid Elementor widget. It comes with predefined skins, so you spend less time designing your blog page.
* **[Post Tiles](https://demo.happyaddons.com/elementor-post-tiles-widget-demo/)** – Now you can showcase your most desirable blog posts exclusively with the Post Tiles elementor widget of Happy Elementor Addons. It’s available with predefined tiles set to achieve an elegant look
* **[Smart Post List](https://demo.happyaddons.com/elementor-smart-post-list-widget-demo/)** – Are you looking for a magnificent listing facility with the highlighted option for your sticky featured article? HappyAddons for elementor Smart Post list elementor widget will handle all of your desirable styles smartly, like featuring the sticky post, filterable post list, and more
* **[Post Carousel](https://demo.happyaddons.com/elementor-post-carousel-widget-demo/)** – The Post carousel feature is now trendy in News Portals or other blogging sites to grab visitors’ attention. Now you can create a stunning post carousel for your site with the Happy elementor Addons for Post Carousel elementor widget
* **[Author List](https://demo.happyaddons.com/elementor-author-list-widget-demo/)** – Decently showcase your creative writers with the Happy elementor Addons Author List elementor widget. It will help you to display all of your authors in one place
* **[WooCommerce Product Grid](https://demo.happyaddons.com/elementor-product-grid-widget-demo/)** – Are you struggling with showcasing your WooCommerce products in perfect grid alignment within WooCommerce? From now, you can display your products in grid views lucratively with Happy elementor Addons Pro Product Grid elementor Widget
* **[WooCommerce Product Carousel](https://demo.happyaddons.com/elementor-product-carousel-widget-demo/)** – Wondering about a perfect WooCommerce Product Carousel widget for Elementor to grab the attention of your customers? Try Happy Elementor Addons Pro’s Product Carousel Widget to make it happen.
* **[WooCommerce Product Category Grid](https://demo.happyaddons.com/elementor-product-category-grid-widget-demo/)** – Sometimes you need to display your WooCommerce - eCommerce products category-wise to target a specific genre of visitors. Our Happy elementor Addons Product Category Grid elementor Widget is the best fit for displaying WooCommerce Products category wise
* **[WooCommerce Product Category Carousel](https://demo.happyaddons.com/elementor-product-category-carousel-widget-demo/)** – From now you can display WooCommerce products in carousels based on specific categories with the help of Happy elementor Addons Pro Product Category Carousel elementor Widget to make them more lucrative
* **[WooCommerce Single Product](https://demo.happyaddons.com/elementor-single-product-demo/)** – Are you looking for a design element to design your single WooCommerce products in various designs within your elementor website? No worries, Happy elementor Addons Single WooCommerce Product elementor Widget will fulfill your desired goal. Check out the demos here.
* **[WooCommerce Mini Cart](https://demo.happyaddons.com/elementor-mini-cart-widget-demo/)** – Want to increase your WooCommerce/eCommerce store’s customer experience? Use the elementor mini cart widget of Happy elementor Addons to boost your conversion rate swiftly.
* **[Advanced Google Map Widget for Elementor](https://demo.happyaddons.com/elementor-google-map-widget-demo/)** – Are you looking to add a map to your elementor website but not the traditional google map? Yes, if you use the Happy Addons Elementor Google Map widget, you can achieve that quickly. You can customize your Elementor Google Map Widget based on your theme color. Also, in HappyAddons Advance Google Map Elementor Widget, you can add your custom label, map marker, legend, and more. 
Happy Addons for Elementor  also brings the Snazzy Map styling within Advanced Google Map Elementor Widget. We have added four built-in styles and also added support for custom JSON input from the official Snazzy Map. So, you can now design your Google Map according to your theme.


### **UNIQUE PRO FEATURES OF HAPPY ELEMENTOR ADDONS TO WATCH OUT FOR**

The premium (PRO) features of Happy Addons truly make it stand out from all the other Elementor add-ons out there right now. You will get the below mentioned much talked about standout premium features in the PRO version of Happy Addons:


### **HAPPY MEGA MENU BUILDER FOR ELEMENTOR:**

Happy Addons brings an amazing mega menu builder for Elementor. With this MegaMenu builder, you can create mega menus like Dribble, Adidas, Puma, weDevs, and more. Our Happy Menu widget will help you show any kind of element to your mega menu items. Like you can show posts, categories, pages, list items, social links, menu icons, and more. Not only that but also you will get a blank Elementor canvas to design your mega menu items.

What Extra Will You Get in the Mega Menu Builder of Happy elementor Addons?

With this Happy mega menu builder elementor widget, you can create any kind of menus.



* **Simple Navigation Menu For Elementor:** You can create a simple nav menu for your Elementor site. You can show and design your WordPress Nav menu items as well.
* **Icon for menu items or megamenu items:** Flexibility to add different types of icons to menu items.
* **Menu Badges for Mega Menu or Simple Nav Menus:** Create a customized badge for your megamenu or simple menu items.
* **Mobile Responsive Mega Menus:** You can create mobile responsive menus, as it has different styling options for mobiles and tablets.

Want to learn How to Create a MegaMenu for Elementor? Watch this detailed tutorial of creating mega menus within Elementor,

[youtube https://www.youtube.com/watch?v=7qmCZFsDkmg&ab_channel=HappyAddons]


### **CROSS-DOMAIN COPY-PASTE: APPLY THE SAME DESIGN TO MULTIPLE DOMAINS WITH A SINGLE CLICK**

If you are creating different web pages with WordPress, you will often try to use the same elements of a web page to other pages over and over again.

To address this issue, the Elementor page builder comes with a free copy and paste elements feature for a single domain. But the problem is, you can not copy and paste an element to other domains.

This is where the goodness of the Happy Addons comes to the rescue! With this tool, you can copy and paste any element (for example, buttons, navigation bars, carousel, accordion, etc.) from one domain to another domain. Cool, right? Don’t miss out on the chance to scale up your working efficiency with the help of Happy Elementor Addons cross domain copy paste elementor extension/ elementor module/ elementor feature. Happy elementor addons are the inventor of the cross domain copy paste feature in the elementor ecosystem. 

[Check Demo](https://demo.happyaddons.com/cross-domain-copy-paste/)


### **PRESET: SAVE YOUR TIME AND EFFORT BY USING THE PRESET FEATURE**

If you try to create your elementor website from scratch and give it a professional appearance, then it will take up a huge amount of time and effort.

To tackle this hassle, the Preset option of the Happy elementor Addons comes into play! Much like its name, it will let you select pre-made designs to create a web page faster and of course without compromising the quality. Currently, there are 400+ elementor preset designs available in Happy Addons for elementor. Try the happy elementor addons preset designs for elementor. Happy elementor addons are the inventor of the preset feature in the elementor ecosystem. 

[Check Demo](https://demo.happyaddons.com/presets-demo/)


### **UNLIMITED SECTION NESTING: USE UNLIMITED SECTION NESTING TO GO BEYOND THE LIMIT**

With Elementor, you can create sections to make room for elements. We feel happy to say that by integrating the Happy Elementor add-ons, you can create infinite sections within a single section.

And as usual, you can insert as many widgets as you want into those sections. Happy elementor addons are the inventor of the unlimited section nesting feature in the elementor ecosystem. 

[Check demo](https://demo.happyaddons.com/unlimited-section-nesting/)


### **LIVE COPY: COPY DESIGNS FROM DEMO SITES TO GET IT DONE RIGHT AWAY!**

Sometimes you may wish to simulate exactly the same design that you see on our demo page. Amazingly, with the Live Copy option, you can do it at your disposal.

This is a go-to way that lets you copy the code of the demo design from the demo site and allows you to use it directly on your Elementor edit panel.

Unlike a theme template, using the demo designs won’t put any pressure on your media server which is a must-have to help load the page faster. Happy elementor addons are the inventor of the live copy elementor demo design feature in the elementor ecosystem. 

[Check Demo](https://demo.happyaddons.com/live-copy/)


### **IMAGE MASKING: MASK YOUR IMAGES WITHIN YOUR ELEMENTOR EDITING PANEL!**

Sometimes, a square or circular-shaped image is not enough to create a good design in elementor. You might need different types of creative and unusual image shapes. HappyAddons for elementor is introducing custom-shaped images to bring a creative touch to your design. Now you will be able to convert your square image into lovely custom shapes. No hassles, just upload your image and choose your shape. Boom! Just done. Very Easy. Happy elementor addons are the inventor of the image masking feature in the elementor ecosystem. 

[Check Demo](https://happyaddons.com/image-masking-demo/)

[youtube https://www.youtube.com/watch?v=0U3wq3oxy2k&t=2s&ab_channel=HappyAddons]


### **HAPPY PARTICLE EFFECT: ADD EXCLUSIVE BACKGROUND PARTICLE EFFECTS TO YOUR WEBSITE!**

Team, happy elementor addons has added three predefined particle effects, which are commonly used, Polygon, NASA, Snow. But you have plenty of options for adding as much as your need with our custom Particle adding option. Moreover, you can customize them at your desired level. You can set the number of Particles, the size of your particles, the speed of the Particle movements, and the flexibility to add Hover Effect to your Particle effects. Try Happy Elementor addons elementor particle effects. 

[Check Demo](https://demo.happyaddons.com/happy-particle-demo/)

[youtube https://www.youtube.com/watch?v=iD83Sr4pFSw&ab_channel=HappyAddons]


### **DISPLAY CONDITION: SHOW, HIDE AND SCHEDULE CONTENT TO DISPLAY ON YOUR SITE ACCORDING TO YOUR NEED!**

This feature will help you to display your content depending on different kinds of conditions like Browser, Operating System, Date Range, Time, and many more. Happy elementor addons are the inventor of the Conditional display or display condition feature in the elementor ecosystem. 

[Check Demo](https://happyaddons.com/display-condition/)

[youtube https://www.youtube.com/watch?v=kiGj1ZyX6T4&ab_channel=HappyAddons]


### **ENJOY EXTRA BENEFITS FROM HAPPY ELEMENTOR ADDONS!**

Our code doesn’t stink and we don’t leave you blindfolded when you need support from us. Apart from the freemium widgets, the plugin will pamper you with a fleet of professional quality features.

For example, it’s compatible with almost every WordPress theme; it’s lightweight and fast; comes up with motion effects, and empowers you with enormous customizability options. In addition, the plugin also works cohesively with the stock Elementor widgets.

If you don’t understand a feature or fail to give it the desired look which was already demonstrated in a demo, or it’s not working as expected – we got your back. Just drop us a line and we will do our best to help you figure a way out.


### **BUGS, TECHNICAL HINTS OR CONTRIBUTE**

Please provide us with constructive feedback, contribute, and file any technical bugs on [GitHub Repository](https://github.com/weDevsOfficial/happy-elementor-addons/issues).

**Stay connected with the Happy Elementor Addons Community**

In case you want to share any ideas on Happy Addons with other users or if you are in any trouble, don’t feel stranded. Stay connected with [the Happy addons community](https://www.facebook.com/groups/HappyAddonsCommunity/).


### **PRIVACY POLICY**

**Happy Addons for Elementor** uses [Appsero](https://appsero.com/) SDK to collect some telemetry data upon the user’s confirmation. This helps us to troubleshoot problems faster & make product improvements.

Appsero SDK **does not gather any data by default.** The SDK only starts gathering basic telemetry data **when a user allows it via the admin notice**. We collect the data to ensure a great user experience for all our users.

Integrating Appsero SDK **DOES NOT IMMEDIATELY** start gathering data, **without confirmation from users in any case.**

Learn more about how [Appsero collects and uses this data](https://appsero.com/privacy-policy/). Additionally, read the weDevs [privacy policy](https://wedevs.com/privacy-policy/) for better knowledge on it.


### **Missing Something in the Happy Elementor Addons?**

If you are still finding some of the missing pieces in the Happy Elementor Addons Elementor Widget Library and want to share them with us then here is the Happy Elementor Addons public roadmap for you. You can submit your ideas and upvote other submitted ideas. And we will bring the elementor features and elementor widgets based on the upvotes in the Happy Elementor addons public roadmap. 

[Submit your ideas here.](https://happyaddons.com/roadmaps/#ideas)


### **HAPPY WITH OUR WORK?**

We are really thankful to you that you have chosen our plugin. If our plugin brings a smile to your face while working, please share your happiness by giving us a 5***** rating in WordPress Org. It will make us happy and won’t take more than 2 mins.

[I’m Happy to Give You 5⭐️](https://wordpress.org/support/plugin/happy-elementor-addons/reviews/?filter=5)


### **ABOUT THE MAKER**

Despite Happy Addons for Elementor, being the newest addition to the product lineup of [weDevs](https://wedevs.com/), it has already managed to win the heart of its users with a staggering 5-star rating. The plugin is programmed in a way so you don’t require any prior coding know-how and is completely cross-browser compatible with mobile responsive features.


== Frequently Asked Questions ==

= Can I use Happy Elementor Addons without Elementor? =

I'm afraid, you cannot use **[Happy Elementor Addons](https://happyaddons.com/)** without Elementor. Happy Elementor Addons is a collection of slick, powerful widgets that works seamlessly with Elementor page builder and it's only for Elementor.

= Does it work along with other Elementor Addons? =

Yes, it does. And you'll get some cool and extra features like Happy Effects for other Elementor Addons or Extensions.

= Does it work with any WordPress theme? =

Yes, it works with any WordPress theme that works with Elementor. And it best works with [Hello Elementor](https://wordpress.org/themes/hello-elementor/).

= Does it work with Elementor Pro? =

Yes, undoubtedly.

= Will Happy Elementor Addons break my site after an update? =

No, It won't break your site or any page where you used Happy Elementor Addons. We put our best effort to make you happy.


== Installation ==

**Step 1:** Upload the plugin file to install by navigating through Plugins➔Add New➔Upload Plugin➔Choose File to Install from your WordPress dashboard or you can simply search for the Happy Addons plugin from the plugin directory by going to Plugins➔Add New and search for the plugin in the search tab to install it on your WordPress site.

**Step 2:** After successful installation, you have to click the "activate" button to activate the happy addons for Elementor.

**Step 3:** When you activate Happy Addons for Elementor you will be redirected to our HappyAddons Dashboard Home Tab.

For a more detailed explanation check out the following documentation

☞ [**How to Install Happy Addons For Elementor**](https://happyaddons.com/docs/happy-addons-for-elementor/getting-started-with-happy-elementor-addons/installation/)


== Screenshots ==

1. Review widget with image offset
2. Icon box widget - capsule design
3. Team member widget
4. Info box widget
5. Skill bars widget
6. Dual button widget
7. Icon box widget with label
8. Happy Effects - available in all kinds of Elementor widgets. And works smoothly with all the 3rd party Elementor addons plugin, Elementor Pro and Elementor
9. Happy Effects - CSS Transform - Rotate
10. happy Effects - CSS Transform - Rotate and Translate
11. Review widget - capsule design
12. Card widget with Happy Effects (Floating Effects)
13. Card widget - capsule design


== Changelog ==

= 3.5.1 - 29 March 2022 =

- Fix: Image Compare widget white space issue
- Fix: 360-degree widget mobile overlay issue

= 3.5.0 - 24 March 2022 =

- Tweak: Removed `_register_controls` deprecated method.
- Tweak: Replace `register_controls` with `register`.
- Tweak: Change default url for PDF Viewer.
- Fix: Miscellaneous deprecations.
- Fix: Setup Wizard redirection issue.
- Improve: Elementor 3.6.1 compatibility.

= 3.4.4 - 1 March 2022 =

- New: Double Opt In support for mailchimp widget.
- Tweak: Improve Slider on load behavior
- Tweak: Improve Image Carousel on load behavior
- Tweak: Comparison Table description field
- Tweak: Comparison Table add button style control for individual item

= 3.4.3 - 17 February 2022 =

- Tweak: Pdf Viewer Dynamic Link tag support
- Tweak: Creative Button Dynamic Link tag support for url
- Fix: Calendly Width fix

= 3.4.2 - 6 February 2022 =

- Tweak: Setup Wizard Performance Improvement

= 3.4.1 - 31 January 2022 =

- New: Comparison Table Widget
- Fix: Card widget alignment issue as gloabl widget
- Fix: Dashboard Analytics Page issue

= 3.4.0 - 22 December 2021 =

- New: Happy Icons v6 (New 53 icons)
- New: Two new shape dividers added ( christmas, christmas 2 )
- Tweak: Pdf Viewer multiple viewer support in same page
- Fix: Happy Clone issue with template type

= 3.3.3 - 12 December 2021 =

- Fix: Social icon missing for viber
- Tweak: Pdf view add support for page selection

= 3.3.2 - 8 December 2021 =

- Code improvement

= 3.3.1 - 6 December 2021 =

- New: Pdf Viewer
- Fix: Image Stack Group icon size overflow issue
- Fix: Review Banner logic
- Fix: Post Tab widget undefined warning issue
- Tweak: Code improvement

= 3.3.0 - 27 October 2021 =

- New: Creative Button Widget
- Fix: Dashboard widget broken style
- Fix: Happy Tooltip JS optimization
- Fix: Privacy policy missing link in setup wizard
- Fix: MailChimp audience tags issue solve
- Fix: Dashboard widgets and features disable all issues.
- Tweak: Replace `_content_template` function with `content_template`.

= 3.2.2 - 29 September 2021 =

- Fix: Setup wizard asset loading
- Fix: Resolved an unexpected warning in admin area while debugging is enabled.
- Fix: Missing Template Engine icon in Elementor Editor.
- Fix: Icon Box widget Badge z-index reduced

= 3.2.1 - 23 September 2021 =

- Fix: Setup wizard improvement and cache issue resolved.

= 3.2.0 - 23 September 2021 =

- New: Setup Wizard for guided plugin configuration
- New: Widget Group in Dashboard
- New: Dashboard to show latest offer & news
- New: Widget uses analytics in Dashboard

= 3.1.0 - 25 August 2021 =

- New: Added disbale option for Column Extended feature
- New: Added disbale option for Text Stroke feature
- New: Added compatibility with PHP 8.0
- Fix: Icon Box badge z-index issue
- Remove: Alignment option from 360deg widget

= 3.0.1 - 8 August 2021 =

- Improve: Review Banner Logic
- Fix: Image Stack group default image missing issue
- Fix: Conflicts with Elementor "Border Type" style control

= 3.0.0 - 3 August 2021 =

- New: Image Stack Group Widget
- New: Image Accordion Widget
- New: Happy Tooltip feature
- New: Added Team Member widget Ligthbox option
- New: Added Horizontal Timeline Title HTML Tag control option
- New: Added Taxonomy List HTML Tag control option
- New: Added Post Tab Title HTML Tag control option
- New: Added News Ticker widget Post Title HTML Tag control option
- New: Added Carousel Widget Title & Subtitle HTML Tag control option
- New: Added Sliders Widget Title & Subtitle HTML Tag control option
- New: Added Global credential key dashboard. User can set credentials in settings pannel and use it globally (Mailchimp Widget, Twitter Feed Widget)
- Update: Image Hover Effect Title HTML Tag control
- Update: All widgets Coding stractrue update
- Update: Happy sellect 2 control update
- Update: Mailchimp form alignment improved and optimized with some coding updates.
- Fix: Taxonomy List Sellect2 issue
- Fix: Post tab Sellect2 issue
- Fix: Post list Sellect2 issue
- Fix: News ticker Sellect2 issue
- Fix: Mailchimp Sellect2 issue
- Fix: Improve some style for compatibility on the content switcher

= 2.27.0 - 5 July 2021 =

- New: Content Switcher Widget

= 2.26.0 - 1 July 2021 =

- New: Prefix and Suffix option for the Fun Factor widget
- New: Link Target option added to Twitter Feed widget
- Tweak: Added Tag for subscriber lists in mailchimp widget
- Fix: Mailchimp integration instruction improved

= 2.25.0 - 16 June 2021 =

- New: Mailchimp Widget
- New: Added Lightbox support to Horizontal Timeline widget
- New: Image Hover Effect hover title html tag option added
- Tweak: Added html tag support to Horizontal Timeline description
- Tweak: Dynamic Tag support for Image Hover effect's image field
- Tweak: Modify select 2 control
- Fix: The Event Widget's events popups responsive issue

= 2.24.1 - 18 May 2021 =

- Tweak: Step Flow title html tag option increased
- Tweak: Gravity form ajax submit enable option
- Fix: Gravity form input height issue
- Fix: 360 Rotation widget fallback background color conflict issue

= 2.24.0 - 25 April 2021 =

- Tweak: Animated Link widget alignment control added
- Fix: Security patches
- Tweak: Removed `Elementor\Scheme_Typography` deprecated function
- Tweak: Happy Elementor Addons not active when Elementor doesn’t meet minimum version requirements

= 2.23.0 - 12 April 2021 =

- New: Animated Link Widget
- New: Infobox widget media direction option
- Fix: Shape Divider issue

= 2.22.1 - 24 March 2021 =

- Fix: Elementor compatibility tag added

= 2.22.0 - 16 March 2021 =

- New: Image Hover Effect Widget
- Fix: Wrapper link issue

= 2.21.1 - 1 March 2021 =

- Fix: Happy Icons blank issue

= 2.21.0 - 28 February 2021 =

- New: Happy Icons v5 (33 new icons)
- New: Section Shape Divider (3 new Happy Shapes)
- Tweak: Removed unnecessary code from event calendar widget

= 2.20.0 - 18 February 2021 =

- New: Text stroke feature
- New: Event Calendar widget
- New: Happy particle effects disable option
- Tweak: Updated kses function to support more attributes
- Tweak: Added html tag support in Data Table widget
- Tweak: Added slider widget dots size control
- Tweak: Added carousel widget dots size control
- Fix: Shape divider spell
- Fix: Chart widgets console error
- Fix: Widget background overlay class mismatch issue
- Fix: Data Table widget compatibility issue with WPML

= 2.19.0 - 20 January 2021 =

- New: Features control panel
- New: Section Shape Divider - 18 custom shapes (Happy Shapes)
- Tweak: Improved elementor missing notice
- Fix: Misc css bug resolved

= 2.18.0 - 5 January 2021 =

- New: Tabs are sortable in Post Tab widget
- Tweak: Added Post tab widget tab hover cursor
- Fix: Equal height control rendering issue
- Fix: Horizontal Timeline inconsistency with Infinite loop

= 2.17.1 - 24 December 2020 =

- Fix: Wrapper link undefined url issue

= 2.17.0 - 23 December 2020 =

- New: Widget equal height feature
- New: Custom arrow icon control in Slider widget
- New: Custom arrow icon control in Carousel widget
- New: Custom arrow icon control in Horizontal timeline widget
- New: Slider arrow size control
- New: Carousel arrow size control
- New: Horizontal timeline arrow size control
- New: Horizontal timeline arrow horizontal position control
- Tweak: Updated Horizontal timeline widget default style
- Tweak: Added % unit in Slider arrow position controls
- Tweak: Added % unit in Carousel arrow position controls
- Tweak: Added % unit in Horizontal timline arrow position control
- Tweak: Separated Floating effects JS handler from main JS file
- Fix: Slider arrow not hiding issue
- Fix: Carousel arrow not hiding issue

= 2.16.1 - 10 December 2020 =

- Fix: WordPress 5.6 compatibility
- Fix: Floating effect dependency loading only when activated
- Fix: Infobox button icon animation
- Fix: JS error in elementor editor

= 2.16.0 - 29 November 2020 =

- Added: Justified Grid lightbox disable option for mobile and tablet
- Added: Image Grid lightbox disable option for mobile and tablet
- Added: Justified Grid default filter select option
- Added: Image Grid default filter select option
- Added: Added .pot file
- Tweak: Improved Justified Grid and Image Grid base style
- Tweak: Improved Image Grid markup - removed extra inner div
- Tweak: Improved on demand assets loading
- Fix: Private page on demand assets loading issue
- Fix: Lightbox and Popup not working with wrapper link issue

= 2.15.0 - 4 November 2020 =

- New: Ready made page templates (Happy Templates)
- New: Horizontal TimeLine widget
- New: Social Share widget
- New: Happy Icons v4 (44 new icons)
- Tweak: Data Table row-cell text link option
- Fix: On Demand Assets Loading compatibility with WPML
- Fix: Post Tab widget compatibility with WPML
- Fix: News Ticker widget compatibility with WPML
- Fix: Pricing Table long feature text breaks into 2nd line issue
- Fix: Pricing Table default style and content issue
- Fix: Text domain inconsistency

= 2.14.3 - 12 October 2020 =

- Update: Appsero client updated to `v1.2.0`
- Tweak: Added Calendy pro feature notice
- Tweak: Added Calendy default username "happyaddons"
- Tweak: Common cached files are loaded once as internal css
- Fix: Card widget badge dynamic tag issue
- Fix: Happy templates popup button auto duplicate issue
- Fix: Removed duplicate On demand assets cache file enqueue
- Fix: Removed broken Review widget schema data
- Fix: Team member widget email envelope icon issue
- Fix: Removed forced open in new window for Logo grid widget

= 2.14.2 - 20 September 2020 =

- Fix: JS loading issue for non logged in users
- Fix: JS loading issue for logged in users
- Fix: All the JS dependent widgets with issue
- Fix: Editor loading issue

= 2.14.1 - 7 September 2020 =

- Fix: JS loading issue for non logged in users

= 2.14.0 - 3 September 2020 =

- New: Updated compatibility with WP 5.5.x
- New: Updated compatibility with Elementor 3.x.x
- New: Twitter feed timestamp settings
- Tweak: Removed unnecessary Elementor kit assets enqueue
- Tweak: Removed common image styles, instead added widget wise
- Fix: Templates compatibility issue with Elementor 3.x.x
- Fix: Script dependency order issue
- Fix: Card and Infobox delete issue
- Fix: Review widget spelling error

= 2.13.3 - 24 August 2020 =

- Fix: HappyAddons Pro assets loading issues
- Fix: Misc style issue

= 2.13.2 - 20 August 2020 =

- Tweak: Removed icons control workaround for HappyIcons
- Tweak: Removed assets loading hook priority
- Tweak: Improved Dual Button default style
- Fix: CSS Transform normal/hover mode not working on frontend issue
- Fix: Color change doens't have any effect on SVG icon issue
- Fix: Card widget image size issue on Firefox and responsive mode

= 2.13.1 - 6 August 2020 =

- Fix: CSS Transform conflict issue

= 2.13.0 - 27 July 2020 =

- New: Data Table widget
- New: `happyaddons/extensions/grid_layer` hook to control Grid Layer
- New: `happyaddons/extensions/background_overlay` hook to control Background Overlay
- New: `happyaddons/extensions/wrapper_link` hook to control Wrapper Link
- New: `happyaddons/extensions/happy_clone` hook to control Happy Clone
- New: `happyaddons/extensions/adminbar_menu` hook to control Adminbar menu
- New: `happyaddons/extensions/floating_effects` hook to control Floating Effects
- New: `happyaddons/extensions/css_transform` hook to control CSS Transform
- New: `happyaddons/extensions/on_demand_cache` hook to control On Demand Assets Loading
- Tweak: Added CSS Transform hover state support
- Tweak: Added Stepflow direction arrow rotatation support
- Tweak: Added Card button full width support
- Tweak: Added Card responsive image positioning
- Tweak: Restored justify alignment in all widgets
- Tweak: Improved base styles in all widgets
- Tweak: Removed widget control panel link from editor panel
- Tweak: Removed HappyAddons shortcut link from finder
- Tweak: Removed unnecessary css
- Tweak: Post List content on/off option
- Tweak: Post List feature image left & top show option
- Fix: Post List date issue
- Fix: WPML link translation issue

= 2.12.3 - 13 July 2020 =

- Tweak: Twitter feed widget icon updated
- Tweak: Twitter feed cache cleaner added
- Tweak: Twitter feed Error handling updated
- Tweak: Social link widget default value
- Fix: Fun factor animation issue
- Fix: Card widget default text spelling error
- Fix: Empty button rendering issue

= 2.12.2 - 10 June 2020 =

- Fix: Template library dark mode compatibility issue
- Fix: Fluent Forms styles issue

= 2.12.1 - 9 June 2020 =

- Fix: GravityForms widget issue causing elementor editor continuous loding

= 2.12.0 - 8 June 2020 =

- New: Happy Templates Library
- New: WP Fluent Forms widget

= 2.11.1 - 4 June 2020 =

- Fix: JS function backward compatibility issue
- Fix: `ha_get_feature_label` JS error issue in Pricing table

= 2.11.0 - 1 June 2020 =

- Tweak: Slide item link support for Carousel widget
- Tweak: Slide item link support for Slider widget
- Tweak: More html tags support for textarea/description type input
- Tweak: Advanced button support for Team Member widget
- Tweak: Restored default placeholder image
- Fix: Adminbar happy icon markup issue
- Fix: Carousel and Slider css issue
- Fix: SVG icon sizing issues in all widgets
- Fix: WPML support issue
- Fix: 360° widget default style

= 2.10.0 - 18 May 2020 =

- New: 360° Rotation widget
- New: Taxonomy List widget

= 2.9.0 - 29 April 2020 =

- New: WPML support for all widgets [Documentation](https://happyaddons.com/docs/happy-addons-for-elementor/happy-features/wpml-support-for-happyaddons-free/)

= 2.8.1 - 5 April 2020 =

- Tweak: Adminbar actions terms updated to more meaningful terms
- Fix: Floating effect not working on frontend
- Fix: Adminbar HappyAddons icon position

= 2.8.0 - 1 April 2020 =

- New: Post Tab widget
- New: Post List widget

= 2.7.3 - 31 March 2020 =

- Tweak: Custom attribute output support for all links
- Tweak: Added pro widgets awarness panel
- Fix: Missing styles issue on page/post clone
- Fix: Popup link not working with link issue
- Fix: Twitter feed issue

= 2.7.2 - 2 March 2020 =

- Fix: Dual Button space between buttons issue

= 2.7.1 - 23 February 2020 =

- Fix: Fun Factor broken markup issue

= 2.7.0 - 20 February 2020 =

- New: Twitter Feed widget
- New: Bar Chart widget
- New: Social Icons widget
- New: Grid Layer feature for designer
- New: Wrapper Link feature for section, column and widget
- Update: Dynamic Tags support in Carousel widget
- Update: Dynamic Tags support in Dual Button widget
- Update: Dynamic Tags support in Logo Grid widget
- Update: Dynamic Tags support in News Ticker widget
- Update: Dynamic Tags support in Pricing Table widget
- Update: Dynamic Tags support in Skills widget
- Update: Dynamic Tags support in Slider widget
- Update: Dynamic Tags support in Testimonial widget
- Fix: Pricing Table widget php warning

= 2.6.1 - 16 February 2020 =

- Fix: Conflict with Rank Math
- Fix: Fun Factor padding issue
- Fix: Stepflow inline editing issue
- Fix: Gravity Forms conditional field issue
- Fix: Inline editing issue in Elementor 2.9.*
- Fix: Select2 width collapse issue in Elementor 2.9.*

= 2.6.0 - 15 January 2020 =

- New: Fun Factor widget
- Update: Page break styling for Gravity Forms widget
- Update: Widgets help link added in "Need Help?" button
- Fix: Image Compare widget extra height issue
- Fix: Step Flow widget title link issue
- Fix: Gravity Forms styling issue
- Fix: Removed welcome notice in admin

= 2.5.0 - 24 December 2019 =

- New: Added Step Flow widget title heading level control
- Update: Tracking system update to comply with wp.org user privacy policy
- Fix: Dark mode Happy Effects heading color

= 2.4.2 - 12 December 2019 =

- Fix: Compatibility with Elementor 2.8.*
- Fix: Extension loading issue for non logged in users

= 2.4.1 - 10 December 2019 =

- Fix: News Ticket single post selection issue
- Fix: Blank icons controls JS error issue (it also fixes EA Table and Elementor FORM issue)
- Fix: Gravity Forms Elementor editor style issue

= 2.4.0 - 3 December 2019 =

- New: Happy Clone - (duplicate post/page from anywhere!)
- New: News Ticker Widget
- New: Fixed size controls in Elementor Button widget
- Fix: Badge offset responsive issue for Icon Box Widget
- Fix: Wrapper is rendered when icon/image is missing issue

= 2.3.0 - 20 November 2019 =

- New: Gravity Forms Widget
- New: Column Order control
- New: Custom Column Width control
- New: weForms section break styles
- Fix: weForms misc style issues

= 2.2.6 - 11 November 2019 =

- Fix: Conflict with Essential Addons causing PHP fatal error
- Fix: PHP cannot declare class `Happy_Addons\Elementor\Finder` issue

= 2.2.5 - 11 November 2019 =

- Tweak: Improved floating effects editing performance
- Fix: Text editor slow performance and rendering lag issue

= 2.2.4 - 8 November 2019 =

- Tweak: Improved on demand assets loading for Elementor theme builder
- Tweak: Improved support for 3rd party header, footer builders
- Fix: Dashboard php error for users with non admin or super admin roles

= 2.2.3 - 6 November 2019 =

- Tweak: Improved support for image optimization plugins. ex: Shortpixel Image Optimiser
- Tweak: Widgets default styles
- Fix: WPForms Pro compatibility issue
- Fix: Image border radius style issue

= 2.2.2 - 16 October 2019 =

- Fix: Widget Control Panel link issue

= 2.2.1 - 15 October 2019 =

- Fix: Text overflow issue in all widgets
- Fix: PHP 5.4 compatibility issue

= 2.2.0 - 7 October 2019 =

- Update: Style copy-paste support improved
- Fix: Image Grid image alt attribute value issue
- Fix: Justified Gallery image alt attribute value issue
- Fix: Skills Bar % sign visibility inconsistency issue

= 2.1.0 - 3 October 2019 =

- New: Widgets control panel link in Elementor Finder
- New: Widgets control panel link in Elementor editor panel
- Update: Added Dual Button layout (Stack and Queue layout)
- Fix: Image Grid and Justified Gallery filter issue for non english languages
- Fix: Justified gallery image alt attribute missing issue
- Fix: Dual Button responsive issue - using layout feature
- Fix: Dual Button default hover text color
- Fix: Widgets Control Panel navigation jump issue

= 2.0.0 - 24 September 2019 =

- New: Dashboard - Widgets Control Panel
- New: Image popup support for Justified Grid
- New: Image popup support for Image Grid
- Update: Improved HTML tag support for description and title fields
- Update: Added more icons in Happy Icons
- Update: Improved HTML escaping support for security
- Fix: Skill Bars admin label fix
- Fix: Missing style issue while copy-pasting widget style
- Fix: Happy Icons cache issue
- Fix: Admin bar menu spacing issue

= 1.5.0 - 27 August 2019 =

- New: Image Grid Widget
- New: Scheme data for Review Widget
- New: Background Overlay - global extension for any widget
- New: Step Flow Widget - direction arrow offset control
- New: Happy Icons - Custom icon font library
- Update: Dynamic Tags support
- Update: New icon manager support with backward compatibility
- Update: Step Flow Widget default view
- Update: On demand caching manager
- Fix: Review ratting icon missing issue
- Fix: Justified Grid Widget filter menu style issue
- Fix: Icon Box Widget badge style missing issue
- Fix: Global widget CSS class missing issue
- Fix: Section and global widget cache missing issue
- Fix: Step Flow arrow alignment issue
- Fix: Skill Bars Widget animation issue

= 1.4.1 - 6 August 2019 =

* Fix: Elementor frontend script dependency and console error issue

= 1.4.0 - 1 August 2019 =

* New: On demand asset loading
* New: On demand cached asset cleaning
* New: Step Flow Widget
* New: Calendly Widget
* New: Flip Box Widget
* New: Pricing Table Widget
* Update: Added animated number support to Number Widget
* Update: Added progress animation to Skill Bars Widget
* Update: Various widgets default styles
* Fix: Various responsive issue

= 1.3.1 - 24 July 2019 =

* Fix: Elementor 2.6.* version compatibility issue

= 1.3.0 - 23 July 2019 =

* New: Carousel Widget
* New: Slider Widget
* Update: Justified Grid Widget hover and animation effects
* Update: Typography scheme support for all FREE widgets
* Fix: Misc styling issue

= 1.2.1 - 18 July 2019 =

* Fix: Unnecessary JS and CSS loading issue fixed

= 1.2.0 - 16 July 2019 =

* New: Justified Grid Widget
* New: Logo Grid Widget
* New: Number Widget

= 1.1.1 =

* New: Testimonial Widget
* New: Floating Effects from -> to controller
* New: Hover animation effect in Card Widget image
* Update: Card Widget button default style
* Update: Dual Button Widget default style
* Fix: WP Forms style issue
* Fix: Card Widget editor mode JS error issue
* Fix: Dual Button Widget inline editing issue

= 1.1.0 =

* Fix: Minor issue fix

= 1.0.5 =

* New: Happy Effects (universal widget extension)
* New: CSS Transform (Happy Effects)
* New: Dual Button Widget
* Fix: Info box icon size issue
* Fix: Icon box icon size issue

= 1.0.4 =

* Fix: Card widget responsive issue
* Fix: Review widget responsive issue

= 1.0.3 =

* Update: Offset settings
* Fix: Offset responsive settings

= 1.0.2 =

* Update: Floating effects settings
* Update: Info box link updated to button
* Fix: Some minor styling issues

= 1.0.1 =

* Fix: Some minor issues

= 1.0.0 =

* New: Card Widget
* New: Gradient Heading Widget
* New: Info Box Widget
* New: Icon Box Widget
* New: Image Compare Widget
* New: Member Widget
* New: Review Widget
* New: Skill Bars Widget
* New: Contact Form 7 Widget
* New: Caldera Form Widget
* New: We Forms Widget
* New: WP Forms Widget
* New: Floating effects (check motion effect panel)
* Update: Plugin structure
* Update: Widgets CSS
* Fix: Card layout issue
* Fix: Contact Form 7 form deletion issue

= 0.0.1 =

* Initial release
