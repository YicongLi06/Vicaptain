<?php do_action( 'htmegabuilder_footer_content' ); ?>
<?php wp_footer(); ?>
</body>
</html>
